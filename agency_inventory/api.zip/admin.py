from django.contrib import admin
from .models import RepairDamageReason, Supplier, ProductCategory, ProductModel, Product

# Register your models here.
admin.site.register(RepairDamageReason)
admin.site.register(Supplier)
admin.site.register(ProductModel)
admin.site.register(ProductCategory)
admin.site.register(Product)
