from rest_framework import viewsets
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated  # if you want auth
from ...models import Product, ProductCategory, ProductModel, Supplier, RepairDamageReason
from ...constants import *
from .serializers import StockProductSerializer, ProductCategorySerializer, ProductModelSerializer, SupplierSerializer, RepairDamageReasonSerializer, BulkImportProductSerializer
from django_filters.rest_framework import DjangoFilterBackend
from utils.pagination_utils import PageNumberPagination
from authentication.base import BaseModelViewSet    
from rest_framework.response import Response
from rest_framework import status
from rest_framework.parsers import MultiPartParser
from django.core.exceptions import ValidationError
from inventory.utils.product_import import ProductImportUtility
from drf_spectacular.utils import extend_schema, OpenApiResponse, OpenApiExample, OpenApiParameter
from drf_spectacular.types import OpenApiTypes
from rest_framework.filters import SearchFilter

class ProductViewSet(BaseModelViewSet):
    """
    A simple ViewSet for viewing and editing widgets.
    """
    queryset = Product.objects.all()
    serializer_class = StockProductSerializer
    # authentication_classes = []
    # permission_classes = []
    pagination_class= PageNumberPagination
    # permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend,SearchFilter]
    search_fields = ['title', 'status', 'supplier__supplier_name', 'created_at','serial_number','description']
    lookup_field = 'slug'
    filterset_fields = ['product_category__type','product_condition','status',"has_serial_number","has_stock"]


class ProductCategoryViewSet(BaseModelViewSet):
    """
    A simple ViewSet for viewing and editing widgets.
    """
    queryset = ProductCategory.objects.all()
    serializer_class = ProductCategorySerializer
    pagination_class= PageNumberPagination
    filter_backends = [DjangoFilterBackend,SearchFilter]
    filterset_fields = [ 'type']
    search_fields = ['title', 'description']
    lookup_field = 'slug'


class ProductModelViewSet(BaseModelViewSet):
    """
    A simple ViewSet for viewing and editing widgets.
    """
    queryset = ProductModel.objects.all()
    serializer_class = ProductModelSerializer
    # authentication_classes = []
    # permission_classes = []
    pagination_class= PageNumberPagination
    filter_backends = [DjangoFilterBackend,SearchFilter]
    filterset_fields = ['category__type', 'created_at']
    search_fields = ['title', 'description']
    lookup_field = 'slug'


class SupplierViewSet(BaseModelViewSet):
    """
    A simple ViewSet for viewing and editing widgets.
    """
    queryset = Supplier.objects.all()
    serializer_class = SupplierSerializer
    # authentication_classes = []
    # permission_classes = []
    pagination_class= PageNumberPagination
    filter_backends = [DjangoFilterBackend,SearchFilter]
    filterset_fields = ['uuid',]
    search_fields = ['supplier_name', 'supplier_email','supplier_phone','supplier_address','description']


class RepairDamageReasonViewSet(BaseModelViewSet):
    """
    A simple ViewSet for viewing and editing widgets.
    """
    queryset = RepairDamageReason.objects.all()
    serializer_class = RepairDamageReasonSerializer
    # authentication_classes = []
    # permission_classes = []
    pagination_class= PageNumberPagination
    filter_backends = [DjangoFilterBackend,SearchFilter]
    filterset_fields = ['title',]
    search_fields = ['title', 'description']
    lookup_field = 'slug'


# https://docs.google.com/spreadsheets/d/1RVWWQL2ChxUCKv_cc2Q4N8DkkZ_od6sbH0O3mp6iO0k/edit?gid=1400463378#gid=1400463378
class BulkImportProductAPI(APIView):
    parser_classes = (MultiPartParser,)
    serializer_class = BulkImportProductSerializer
    
    @extend_schema(
        summary="Bulk import products from Excel/CSV file",
        description="Upload an Excel or CSV file to bulk import products. The file should contain product data with required and optional columns.",
        request={
            'multipart/form-data': {
                'type': 'object',
                'properties': {
                    'file': {
                        'type': 'string',
                        'format': 'binary',
                        'description': 'Excel or CSV file containing product data'
                    }
                }
            }
        },
        responses={
            201: OpenApiResponse(
                description="Products imported successfully",
                examples=[
                    OpenApiExample(
                        "Success Response",
                        value={
                            "status": "success",
                            "message": "Successfully imported 5 products"
                        }
                    )
                ]
            ),
            400: OpenApiResponse(
                description="Invalid file or data",
                examples=[
                    OpenApiExample(
                        "Error Response",
                        value={
                            "status": "error",
                            "errors": ["Row 1: Product category is required"]
                        }
                    )
                ]
            )
        }
    )
    def post(self, request):
        if 'file' not in request.FILES:
            return Response({'error': 'No file provided'}, status=status.HTTP_400_BAD_REQUEST)

        file = request.FILES['file']
        
        try:
            imported_count = ProductImportUtility.process_import_file(file, request.user)
            
            return Response({
                'status': 'success',
                'message': f'Successfully imported {imported_count} products'
            }, status=status.HTTP_201_CREATED)

        except ValidationError as e:
            return Response({
                'status': 'error',
                'errors': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response({
                'status': 'error',
                'message': str(e)
            }, status=status.HTTP_400_BAD_REQUEST)