from rest_framework.routers import DefaultRouter
from django.urls import path,include
from django.conf import settings
from . import views

router = DefaultRouter()
router.register(r'product', views.ProductViewSet)
router.register(r'product-category', views.ProductCategoryViewSet)
router.register(r'product-model', views.ProductModelViewSet)
router.register(r'product-supplier', views.SupplierViewSet)
router.register(r'repair-damage-reasons', views.RepairDamageReasonViewSet)


urlpatterns = [
    path('bulk-import-product/', views.BulkImportProductAPI.as_view(), name='bulk-import-product'),
]

urlpatterns += router.urls