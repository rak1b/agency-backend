# app/serializers.py
from rest_framework import serializers
from ...models import Product, ProductCategory, ProductModel, Supplier, RepairDamageReason
from inventory.constants import *
from drf_spectacular.utils import extend_schema_field
from drf_spectacular.types import OpenApiTypes


class ProductCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductCategory
        read_only_fields = ['created_at','updated_at','deleted_at','deleted_by','is_deleted']
        exclude = ['deleted_at','deleted_by','is_deleted']
class ProductModelSerializer(serializers.ModelSerializer):
    total_product_stock = serializers.ReadOnlyField(source='get_total_product_count')
    product_category_details = ProductCategorySerializer(read_only=True,source='category')
    
    class Meta:
        model = ProductModel
        read_only_fields = ['created_at','updated_at','deleted_at','deleted_by','is_deleted']
        exclude = ['deleted_at','deleted_by','is_deleted']
class SupplierSerializer(serializers.ModelSerializer):
    class Meta:
        model = Supplier
        read_only_fields = ['created_at','updated_at','deleted_at','deleted_by','is_deleted']
        exclude = ['deleted_at','deleted_by','is_deleted']
class RepairDamageReasonSerializer(serializers.ModelSerializer):
    class Meta:
        model = RepairDamageReason
        read_only_fields = ['created_at','updated_at','deleted_at','deleted_by','is_deleted']
        exclude = ['deleted_at','deleted_by','is_deleted']
class StockProductSerializer(serializers.ModelSerializer):
    product_category_details = ProductCategorySerializer(read_only=True,source='product_category')
    product_model_details = ProductModelSerializer(read_only=True,source='product_model')
    supplier_details = SupplierSerializer(read_only=True,source='supplier')
    class Meta:
        model = Product
        read_only_fields = ['created_at','updated_at','deleted_at','deleted_by','is_deleted']
        exclude = ['deleted_at','deleted_by','is_deleted']
class BulkImportProductSerializer(serializers.Serializer):
    file = serializers.FileField(
        help_text="Excel or CSV file containing product data. Required columns: product_category, title. Optional columns: product_model, supplier_name, supplier_email, supplier_phone, supplier_address, description, has_serial_number, has_stock, stock, serial_number, product_condition, invoice_number, price, status, reason_title, comment"
    )
    class Meta:
        model = Product
        fields = ['file']

