import uuid
from django.db import models
from .constants import *
from authentication.models import BaseModel
from django.utils.text import slugify
from django.utils.crypto import get_random_string
from utils.slug_utils import generate_unique_slug, generate_product_slug
# def generate_unique_slug(instance):
#     base_slug = slugify(instance.title)
#     slug = base_slug
#     num = 1

#     # while Product.objects.filter(slug=slug).exclude(pk=instance.pk).exists():
#     while Product.objects.filter(slug=slug).exists():
#         slug = f"{base_slug}-{num}"
#         num += 1

#     return slug

# Create your models here.
class RepairDamageReason(BaseModel):
    title = models.CharField(max_length=100)
    slug = models.SlugField(unique=True, null=True, blank=True, editable=False)
    description = models.TextField(max_length=1200,null=True,blank=True)

    def __str__(self):
        return self.title
    
    def save(self, *args, **kwargs):
        if not self.slug and self.title:
            self.slug = generate_unique_slug(self.title,self)
        super().save(*args, **kwargs)

class Supplier(BaseModel):
    uuid = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False
    )
    supplier_name = models.CharField(max_length=100)
    supplier_email = models.CharField(max_length=100)
    supplier_phone = models.CharField(max_length=100)
    supplier_address= models.CharField(max_length=100)
    description = models.TextField(max_length=1200,null=True,blank=True)

    def __str__(self):
        return self.supplier_name

class ProductCategory(BaseModel):
    type = models.CharField(max_length=100, choices=ProductTypeChoice.choices, default=ProductTypeChoice.TERMINAL)
    title = models.CharField(max_length=100)
    slug = models.SlugField(unique=True, null=True, blank=True, editable=False)
    description = models.TextField(max_length=1200,null=True,blank=True)
    
    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.slug and self.title:
            self.slug = generate_unique_slug(self.title,self)
        super().save(*args, **kwargs)

class ProductModel(BaseModel):
    category = models.ForeignKey(ProductCategory, on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    slug = models.SlugField(unique=True, null=True, blank=True, editable=False)
    description = models.TextField(max_length=1200,null=True,blank=True)
    low_quantity_threshold = models.SmallIntegerField(default=0)

    def __str__(self):
        return self.title
    
    def save(self, *args, **kwargs):
        if not self.slug and self.title:
            self.slug = generate_unique_slug(self.title,self)
        super().save(*args, **kwargs)
        
    def get_with_serial_product_count(self):
        return self.product_set.filter(has_serial_number=True).count()
    
    def get_without_serial_product_count(self):
        products = self.product_set.filter(has_serial_number=False)
        total_stock = products.aggregate(total_stock=models.Sum('stock'))['total_stock'] or 0
        return total_stock
    
    def get_total_product_count(self):
        total_stock = self.get_without_serial_product_count() + self.get_with_serial_product_count()
        return total_stock
    

class Product(BaseModel):
    product_category = models.ForeignKey(ProductCategory, on_delete=models.CASCADE)
    product_model = models.ForeignKey(ProductModel, on_delete=models.SET_NULL, null=True, blank=True)
    supplier =  models.ForeignKey(Supplier, on_delete=models.SET_NULL, null=True, blank=True)
    title = models.CharField(max_length=250,null=True,blank=True)
    slug = models.SlugField(unique=True, null=True, blank=True, editable=False)
    description = models.TextField(max_length=1200,null=True,blank=True)
    has_serial_number = models.BooleanField(default=False)
    has_stock = models.BooleanField(default=False)
    stock = models.PositiveBigIntegerField(default=0)
    serial_number = models.CharField(max_length=250,null=True,blank=True)
    product_condition = models.CharField(max_length=100, choices=ProductConditionChoice.choices, default=ProductConditionChoice.NEW)
    invoice_number = models.CharField(max_length=250,null=True,blank=True)
    price = models.DecimalField(default=0.00, decimal_places=2, max_digits=10)
    status = models.CharField(max_length=100,choices=ProductStatusChoice.choices, default=ProductStatusChoice.IN_STOCK)
    reason = models.ManyToManyField(RepairDamageReason,blank=True)
    reason_title = models.TextField(blank=True, null=True)
    comment = models.TextField(blank=True, null=True)
 
    def __str__(self):
        return f"{self.title} {self.stock} ({self.product_category} {self.product_model})"
    
    def save(self, *args, **kwargs):
        if not self.slug and self.title:
            self.slug = generate_product_slug(self.title, self)
        super().save(*args, **kwargs)

    def decrease_stock(self, qty=1):
        if self.has_serial_number:
            raise ValueError("Cannot adjust stock on a serial-tracked product")
        if self.stock < qty:
            raise ValueError("Insufficient stock")
        self.refresh_from_db()
        self.stock -= qty
        self.save()

    def increase_stock(self, qty=1):
        if self.has_serial_number:
            raise ValueError("Cannot adjust stock on a serial-tracked product")
        self.refresh_from_db()
        self.stock += qty
        self.save()
    def mark_as_sent(self):
        self.status = ProductStatusChoice.SENT_TO_CUSTOMER
        self.save()
# class InventoryLog(BaseModel):
#     model_id = 
#     entity_id =
