from django.db import models
from django.utils.translation import gettext_lazy as _

class ProductTypeChoice(models.TextChoices):
    TERMINAL = "TERMINAL", _("Terminal")
    ACCESSORIES = "ACCESSORIES", _("Accessories")


class ProductConditionChoice(models.TextChoices):
    NEW = "New", _("New")
    USED = "Used", _("Used")


class ProductStatusChoice(models.TextChoices):
    IN_STOCK = "IN STOCK", _("IN STOCK")
    SENT_TO_CUSTOMER = "SENT TO CUSTOMER", _("SENT TO CUSTOMER")
    IN_REPAIR = "IN REPAIR", _("IN REPAIR")
    DAMAGED = "DAMAGED", _("DAMAGED")
    LOSS = "LOSS", _("LOSS")
