import pandas as pd
from django.core.exceptions import ValidationError
from django.utils.text import slugify
from django.db import transaction
from inventory.models import Product, ProductCategory, ProductModel, Supplier
from inventory.constants import ProductConditionChoice, ProductStatusChoice
from utils.slug_utils import generate_product_slug
import time

class ProductImportUtility:
    @staticmethod
    def validate_choice_field(value, choices, field_name):
        if value not in [choice[0] for choice in choices]:
            raise ValidationError(f"Invalid {field_name}: {value}. Choices are: {[choice[0] for choice in choices]}")
        return value

    @staticmethod
    def get_or_create_related_objects(row):
        # Get or create product category
        category_title = row.get('product_category')
        if not category_title:
            raise ValidationError("Product category is required")
        category= ProductCategory.objects.filter(title=category_title).first()
        if not category:
            raise ValidationError(f"Product category with title {category_title} not found")

        # Get or create product model if provided
        model = None
        model_title = row.get('product_model')
        if model_title:
            model, _ = ProductModel.objects.get_or_create(
                title=model_title,
                category=category
            )

        # Get or create supplier if provided
        supplier = None
        supplier_uuid = row.get('supplier_uuid')
        if supplier_uuid:
            supplier= Supplier.objects.filter(uuid=supplier_uuid).first()
            if not supplier:
                raise ValidationError(f"Supplier with uuid {supplier_uuid} not found")

        return category, model, supplier

    @staticmethod
    def process_row(row, user):
        try:
            # Get or create related objects
            category, model, supplier = ProductImportUtility.get_or_create_related_objects(row)

            # Validate choice fields
            product_condition = ProductImportUtility.validate_choice_field(
                row.get('product_condition', ProductConditionChoice.NEW),
                ProductConditionChoice.choices,
                'product_condition'
            )
            
            status = ProductImportUtility.validate_choice_field(
                row.get('status', ProductStatusChoice.IN_STOCK),
                ProductStatusChoice.choices,
                'status'
            )
            has_stock = False
            if row.get('has_serial_number', False):
                has_stock = True
            # Create product
            title = row.get('title', '')
            if not title or title == '':
                title = f"{category.title} {model.title} {time.strftime('%Y-%m-%d')}"
            
            # Create product with generated slug
            product = Product(
                product_category=category,
                product_model=model,
                supplier=supplier,
                title=title,
                slug=generate_product_slug(title),
                description=row.get('description', ''),
                has_serial_number=row.get('has_serial_number', False),
                has_stock=row.get('has_stock', False),
                stock=row.get('stock', 1),
                serial_number=row.get('serial_number', ''),
                product_condition=product_condition,
                invoice_number=row.get('invoice_number', ''),
                price=row.get('price', 0.0),
                status=status,
                comment=row.get('comment', '')
            )

            product.full_clean()
            
            return product, None
        except Exception as e:
            return None, str(e)

    @staticmethod
    def process_import_file(file, user):
        # Validate file extension
        if not file.name.endswith(('.xlsx', '.xls', '.csv')):
            raise ValidationError('Invalid file format. Please upload an Excel or CSV file.')

        # Read the file
        if file.name.endswith('.csv'):
            df = pd.read_csv(file)
        else:
            df = pd.read_excel(file)

        # Convert DataFrame to list of dictionaries
        records = df.to_dict('records')

        products_to_create = []
        errors = []

        # Process each row
        for index, row in enumerate(records, start=1):
            product, error = ProductImportUtility.process_row(row, user)
            has_serial_number = row.get('has_serial_number', False)
            stock = row.get('stock', 1)
            if has_serial_number == True  and stock > 1:
                raise ValidationError(f"Row {index}: Stock can not be greater than 1 for products without serial numbers")
            if product:
                products_to_create.append(product)
            else:
                errors.append(f"Row {index}: {error}")

        if errors:
            raise ValidationError(errors)

        # Bulk create products in a transaction
        with transaction.atomic():
            Product.objects.bulk_create(products_to_create)

        return len(products_to_create) 