import pandas as pd
from ..constants import ProductConditionChoice, ProductStatusChoice
import time

def create_demo_excel():
    # Sample data
    data = {
        'product_category': ['Electronics', 'Electronics', 'Furniture', 'Furniture', 'Office Supplies'],
        'title': [
            f'Laptop Pro {int(time.time())}',
            f'Wireless Mouse {int(time.time()) + 1}',
            f'Office Chair {int(time.time()) + 2}',
            f'Desk Lamp {int(time.time()) + 3}',
            f'Notebook Set {int(time.time()) + 4}'
        ],
        'product_model': ['LP-2024', 'WM-2024', 'OC-2024', 'DL-2024', 'NS-2024'],
        'supplier_name': ['TechSupplies Inc', 'TechSupplies Inc', 'Furniture World', 'Lighting Solutions', 'Office Depot'],
        'supplier_email': ['tech@example.com', 'tech@example.com', 'furniture@example.com', 'lighting@example.com', 'office@example.com'],
        'supplier_phone': ['1234567890', '1234567890', '0987654321', '1122334455', '5566778899'],
        'supplier_address': ['123 Tech St', '123 Tech St', '456 Furniture Ave', '789 Light Blvd', '321 Office Park'],
        'description': [
            'High-performance laptop with latest specs',
            'Ergonomic wireless mouse',
            'Comfortable office chair with lumbar support',
            'Adjustable LED desk lamp',
            'Set of 5 premium notebooks'
        ],
        'has_serial_number': [True, True, False, False, False],
        'has_stock': [True, True, True, True, True],
        'stock': [10, 50, 15, 30, 100],
        'serial_number': ['SN-LP-001', 'SN-WM-001', '', '', ''],
        'product_condition': [
            ProductConditionChoice.NEW,
            ProductConditionChoice.NEW,
            ProductConditionChoice.NEW,
            ProductConditionChoice.NEW,
            ProductConditionChoice.NEW
        ],
        'invoice_number': ['INV-001', 'INV-002', 'INV-003', 'INV-004', 'INV-005'],
        'price': [999.99, 29.99, 199.99, 49.99, 19.99],
        'status': [
            ProductStatusChoice.IN_STOCK,
            ProductStatusChoice.IN_STOCK,
            ProductStatusChoice.IN_STOCK,
            ProductStatusChoice.IN_STOCK,
            ProductStatusChoice.IN_STOCK
        ],
        'reason_title': ['', '', '', '', ''],
        'comment': ['Latest model', 'Bluetooth version', 'Black color', 'White color', 'A4 size']
    }

    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Replace NaN with empty string for serial_number
    df['serial_number'] = df['serial_number'].fillna('')

    # Save to Excel
    df.to_excel('demo_product_import.xlsx', index=False)
    print("Demo Excel file created successfully: demo_product_import.xlsx")

if __name__ == "__main__":
    create_demo_excel()