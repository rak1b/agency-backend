from rest_framework import permissions
from authentication.models import Permission, RolePermission

class HasPermission(permissions.BasePermission):
    """
    Custom permission to check if user has specific permission
    """
    def __init__(self, required_permission):
        self.required_permission = required_permission

    def has_permission(self, request, view):
        # Superuser has all permissions
        if request.user.is_superuser:
            return True

        # Get user's roles
        user_roles = request.user.role.all()
        
        # Get all permissions from user's roles
        role_permissions = RolePermission.objects.filter(role__in=user_roles).prefetch_related('permissions')
        
        # Check if user has the required permission
        for role_perm in role_permissions:
            if role_perm.permissions.filter(code=self.required_permission).exists():
                return True
                
        return False

class HasAnyPermission(permissions.BasePermission):
    """
    Custom permission to check if user has any of the specified permissions
    """
    def __init__(self, required_permissions):
        self.required_permissions = required_permissions

    def has_permission(self, request, view):
        # Superuser has all permissions
        if request.user.is_superuser:
            return True

        # Get user's roles
        user_roles = request.user.role.all()
        
        # Get all permissions from user's roles
        role_permissions = RolePermission.objects.filter(role__in=user_roles).prefetch_related('permissions')
        
        # Check if user has any of the required permissions
        for role_perm in role_permissions:
            if role_perm.permissions.filter(code__in=self.required_permissions).exists():
                return True
                
        return False