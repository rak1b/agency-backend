from datetime import datetime
from authentication.permissions import HasPermission, HasAnyPermission
from authentication.utils import auth_utils, email_utils
from .serialiers import *
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from ..utils.auth_utils import validated_merchant_user, process_code
from ..utils.jwt_utils import generate_tokens, verify_jwt_token
from authentication.models import User, Merchant, Role, Permission, RolePermission
from rest_framework_simplejwt.authentication import JWTAuthentication
from django.contrib.auth import authenticate
from rest_framework import status
from rest_framework import viewsets
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from rest_framework.generics import UpdateAPIView
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import get_object_or_404
from rest_framework.generics import UpdateAPIView
from django_filters.rest_framework import DjangoFilterBackend
from Config.utils.pagination import PageNumberPagination

from django.db.models import Q
from drf_spectacular.utils import extend_schema, OpenApiParameter, OpenApiExample
from rest_framework.parsers import MultiPartParser, FormParser

from django.utils.decorators import method_decorator
from security.decorators import login_attempt_limit
from authentication.api.mobile.utils.auth_utils import validated_user_account, updateLastLoginInfo
from authentication.api.utils.auth_utils import verify_confirmation, validated_merchant_user
from django.apps import apps
from drf_spectacular.types import OpenApiTypes
from rest_framework import mixins
from django.contrib.auth.hashers import make_password

class UserAPI(viewsets.ModelViewSet):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    lookup_field = 'slug'
    

# Define your views here
class WebUserLoginView(APIView):
    authentication_classes = []
    permission_classes = []

    @extend_schema(request=LoginRequestSerializer,responses={},tags=['Authentication & Authorization'])
    def post(self, request):
        context = {}
        mid_info = request.data.get('mid')
        email = request.data.get('email')
        password = request.data.get('password')
        account = validated_user_account(email)
        if not account:
            context['detail'] = 'No Valid Account Found'
            return Response(context,status = status.HTTP_400_BAD_REQUEST)
        user_info = authenticate(email=email, password=password)
        if user_info:
            updateLastLoginInfo(request,user_info)
            context['id'] = account.pk
            context['profile_image'] = request.build_absolute_uri(user_info.image.url) if user_info.image else None
            context['username'] = user_info.name
            context['email'] = user_info.email
            context['phone'] = user_info.phone
            access_token, refresh_token = generate_tokens({'user_id':user_info.id,'user_name':user_info.name,'role':'3','role_title':'merchant'})
            context['access_token'] = access_token
            context['refresh_token'] = refresh_token
            return Response(context)
        else:
            context['detail'] = 'Invalid Email or Password'
            return Response(context,status = status.HTTP_400_BAD_REQUEST)

@method_decorator(login_attempt_limit(max_attempts_per_day=5), name='dispatch')
class WebLoginView(APIView):
    authentication_classes = []
    permission_classes = []

    @extend_schema(request=LoginRequestSerializer,responses={},tags=['Authentication & Authorization'])
    def post(self, request):
        context = {}
        mid_info = request.data.get('mid')
        email = request.data.get('email')
        password = request.data.get('password')
        account = validated_user_account(email)
        if not account:
            context['detail'] = 'No Valid Account Found'
            return Response(context,status = status.HTTP_400_BAD_REQUEST)
        # verified = validate_mid_account(mid_info,account.merchant_identifier)
        # if not verified:
        #     return Response({"detail":"Invalid MID! Please contact your service provider."},status = status.HTTP_400_BAD_REQUEST)
        user_info = authenticate(email=email, password=password)
        if user_info:
            updateLastLoginInfo(request,user_info)
            # context['id'] = account.pk
            # context['client_id'] = account.merchant_identifier
            # context['profile_image'] = request.build_absolute_uri(user_info.image.url) if user_info.image else None
            # context['designation'] = account.designation
            # context['username'] = user_info.name
            # context['email'] = user_info.email
            # context['phone'] = user_info.phone
            access_token, refresh_token = generate_tokens({'user_id':account.user.id,'user_name':user_info.name,'role':'3','role_title':'merchant'})
            context['access_token'] = access_token
            context['refresh_token'] = refresh_token
            return Response(context)
        else:
            context['detail'] = 'Invalid Email or Password'
            return Response(context,status = status.HTTP_400_BAD_REQUEST)

class WebRefreshTokenView(APIView):
    authentication_classes =[]
    permission_classes = []
    
    @extend_schema(request=RefreshTokenReqeustSerializer,responses={},tags=['Authentication & Authorization'])
    def post(self, request):
        refresh_token = request.data.get('refresh_token')
        if not refresh_token:
            return Response({'detail': 'Invalid payload data'}, status=400)
        decoded_data = verify_jwt_token(refresh_token, token_type='refresh')
        
        if decoded_data:
            access_token, _ = generate_tokens({'user_id': decoded_data['user_id'], 'role': decoded_data['role']})
            return Response({"access_token":access_token})
        else:
            return Response({'error': 'Invalid or expired refresh token'}, status=401)


class PasswordChangeView(APIView):
    permission_classes = []
    authentication_classes = []
    serializer_class = ForgetPasswordRequestSerializer
    
    @extend_schema(request=ForgetPasswordRequestSerializer,tags=['Account-Util-API'])
    def post(self, request):
        serializer = ForgetPasswordRequestSerializer(data=request.data)
        if serializer.is_valid():
            email_or_phone = serializer.validated_data['email_or_phone']
            user = auth_utils.validated_user(email_or_phone)
            if user:
                import re
                regex = re.compile(r'([A-Za-z0-9]+[.-_])*[A-Za-z0-9]+@[A-Za-z0-9-]+(\.[A-Z|a-z]{2,})+')
                if re.fullmatch(regex, email_or_phone):
                    data = auth_utils.process_code(user.email)
                    email_utils.send_forget_password_email(user.email, data)
                    return Response({"detail":"An OTP has been sent to your email."},status=status.HTTP_200_OK)
                else:
                    confirmation = auth_utils.create_user_confirmation(user.phone)
                    # sms_utils.send_single_sms(confirmation.identifier,confirmation.code)
                    return Response({"detail":"An OTP has been sent to your phone."},status=status.HTTP_200_OK)
            return Response({"data":{"email_or_phone":["No valid account found"]}},status=status.HTTP_400_BAD_REQUEST)
        return Response({"data":serializer.errors},status=status.HTTP_400_BAD_REQUEST)

class PasswordChangeConfirmView(APIView):
    permission_classes = []
    authentication_classes = []
    serializer_class = ForgetPasswordConfirmSerializer
    
    @extend_schema(request=ForgetPasswordConfirmSerializer,tags=['Account-Util-API'])
    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            email_or_phone = serializer.validated_data['email_or_phone']
            otp = serializer.validated_data['otp']
            new_password = serializer.validated_data['new_password']
            confirmation = auth_utils.verify_confirmation(email_or_phone,otp)
            if confirmation:
                confirmation.is_used = True
                confirmation.save()
                user = auth_utils.validated_user(email_or_phone)
                user.set_password(new_password)
                user.save()
                return Response({"detail":"Password reset successfully done."},status=status.HTTP_200_OK)
            return Response({"data":{"identifier":['Invalid otp or identifier']}},status=status.HTTP_400_BAD_REQUEST)
        return Response({"data":serializer.errors},status=status.HTTP_400_BAD_REQUEST)

class WebResetPasswordAPIView(APIView):
    permission_classes = [IsAuthenticated]
    serializer_class = ResetPasswordRequestSerializer
    
    @extend_schema(request=ResetPasswordRequestSerializer,tags=['Account-Util-API'])
    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            user = request.user
            old_password = serializer.validated_data['old_password']
            user_info = authenticate(email=user.email, password=old_password)
            if user_info:
                new_password = serializer.validated_data['new_password']
                user.set_password(new_password)
                user.save()
                return Response({"detail":"Password reset successfully done."},status=status.HTTP_200_OK)
            return Response({"detail": "Invalid old password"},status=status.HTTP_400_BAD_REQUEST)
        return Response({"data":serializer.errors},status=status.HTTP_400_BAD_REQUEST)





class UserPermissionsView(APIView):
    # authentication_classes = []
    # permission_classes = []
    permission_classes = [IsAuthenticated]
    serializer_class = RolePermissionSerializer
    
    @extend_schema(request=RolePermissionSerializer,tags=['Authentication & Authorization'])
    def get(self, request, *args, **kwargs):
        user = request.user
        # user= User.objects.get(id=2)
        if user != "AnonymousUser":
            # Assuming user.roles is the related name for the M2M relationship
            roles = user.role.all()

            # Get all permissions from the roles
            role_permissions = RolePermission.objects.filter(role__in=roles).prefetch_related('permissions')

            # Gather all permission instances
            permissions = set()
            for rp in role_permissions:
                permissions.update(rp.permissions.all())

            # Optionally serialize permissions if needed
            permission_data = [perm.code for perm in permissions]  # Adjust fields as necessary

            # Include account details as well
            account_serializer = AccountDetailsSerializer(user, context={'request': request})

            response = {
                'data': {
                    # 'account': account_serializer.data,
                    'permissions': permission_data,
                },
                'detail': 'Account permissions retrieved successfully'
            }
            return Response(response, status=status.HTTP_200_OK)
        return Response({"data":{"account":["Account Not Found"]}},status=status.HTTP_400_BAD_REQUEST)
    
class SectionWiseUserPermissionAPI(viewsets.GenericViewSet,mixins.ListModelMixin):
    serializer_class = SectionWiseUserPermissionSerializer
    queryset = Section.objects.all()
    def get_queryset(self):
        user = self.request.user
        roles = user.role.all()
        role_permissions = RolePermission.objects.filter(role__in=roles).values_list('permissions',flat=True)
        sections = Section.objects.filter(permission_of_section__in=role_permissions).distinct()
        return sections
    
    def get_serializer_context(self):
        context = super().get_serializer_context()
        context['user'] = self.request.user
        context['request'] = self.request
        return context

class RoleViewSet(viewsets.GenericViewSet,mixins.ListModelMixin):
    """
    ViewSet for managing roles and their permissions.
    """
    queryset = Role.objects.all()
    serializer_class = AccountRoleSerializer
    filter_backends = [DjangoFilterBackend]
    filterset_fields = []
class AllSectionWisePermissionAPI(viewsets.GenericViewSet,mixins.ListModelMixin):
    queryset = Section.objects.all()
    serializer_class = AllSectionWisePermissionSerializer
    pagination_class = None

    
class AssignPermissionToRoleAPI(viewsets.ModelViewSet):
    serializer_class = AssignPermissionToRoleSerializer
    queryset = RolePermission.objects.all()


def get_model_examples():
    model_examples = []
    for app_config in apps.get_app_configs():
        for model in app_config.get_models():
            if hasattr(model, 'history'):
                model_examples.append(
                    OpenApiExample(
                        f'{model._meta.verbose_name}',
                        value=f'{app_config.label}.{model.__name__}',
                        description=f'Example for {model._meta.verbose_name} model'
                    )
                )
    return model_examples

class HistoryViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]
    serializer_class = HistorySerializer
    pagination_class = PageNumberPagination

    @extend_schema(
        parameters=[
            OpenApiParameter(
                name='model',
                type=OpenApiTypes.STR,
                location=OpenApiParameter.QUERY,
                description='Model name in format "app_name.ModelName"',
                examples=get_model_examples()
            ),
            OpenApiParameter(
                name='id',
                type=OpenApiTypes.INT,
                location=OpenApiParameter.QUERY,
                description='ID of the object to get history for',
                examples=[
                    OpenApiExample(
                        'Example ID',
                        value=123,
                        description='Example ID value'
                    )
                ]
            )
        ],
        responses={
            200: HistorySerializer(many=True),
            400: {'detail': 'Model name and object ID are required.'},
            404: {'detail': 'Object not found.'}
        }
    )
    def list(self, request, *args, **kwargs):
        model_name = request.query_params.get('model')
        object_id = request.query_params.get('id')
        
        if not model_name or not object_id:
            return Response(
                {'detail': 'Model name and object ID are required.'},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            # Get the model class
            model = apps.get_model(model_name)
            instance = model.objects.get(id=object_id)
            
            # Get history records
            history_records = instance.get_history()
            
            # Paginate the results
            paginator = self.pagination_class()
            page = paginator.paginate_queryset(history_records, request)
            
            if page is not None:
                serializer = self.serializer_class(page, many=True)
                return paginator.get_paginated_response(serializer.data)
            
            serializer = self.serializer_class(history_records, many=True)
            return Response(serializer.data)
            
        except LookupError:
            return Response(
                {'detail': 'Model not found.'},
                status=status.HTTP_400_BAD_REQUEST
            )
        except model.DoesNotExist:
            return Response(
                {'detail': 'Object not found.'},
                status=status.HTTP_404_NOT_FOUND
            )
