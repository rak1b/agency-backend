from rest_framework import serializers
from authentication.models import *
from rest_framework.validators import UniqueValidator
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.auth.models import Group
from django.db import models
from django.contrib.auth.hashers import make_password


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id','name','email','phone','password','role',]
        lookup_field = 'slug'
        write_only_fields = ['password']
    
    def create(self, validated_data):
        password = validated_data.pop('password',None)
        roles = validated_data.pop('role',None)
        if password:
            validated_data['password'] = make_password(password)
        user = super().create(validated_data)
        if roles:
            for role in roles:
                user.role.add(role)
        user.save()
        return user

    def update(self, instance, validated_data):
        password = validated_data.pop('password',None)
        if password:
            instance.password = make_password(password)
        roles = validated_data.pop('roles',None)
        if roles:
            instance.role.clear()
            for role in roles:
                instance.role.add(role)
        instance.save()
        return instance

class LoginRequestSerializer(serializers.Serializer):
    email = serializers.CharField()
    password = serializers.CharField()

class RefreshTokenReqeustSerializer(serializers.Serializer):
    refresh_token = serializers.CharField(required=True)


        
class ForgetPasswordRequestSerializer(serializers.Serializer):
    email_or_phone = serializers.CharField(required=True)

class ForgetPasswordConfirmSerializer(serializers.Serializer):
    email_or_phone = serializers.CharField(required=True)
    otp = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

class ResetPasswordRequestSerializer(serializers.Serializer):
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)
    confirm_new_password = serializers.CharField(required=True)

class AccountPropertiesSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['email','username','phone','image','address']
        
class AccountRoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = '__all__'
        

class SectionMinimizedSerializer(serializers.ModelSerializer):
    class Meta:
        model = Section
        fields = ['id','slug','name']
        


        
class PermissionMinimizedSerializer(serializers.ModelSerializer):
    # section = SectionMinimizedSerializer()
    class Meta:
        model = Permission
        exclude = ['section']        
class SectionWiseUserPermissionSerializer(serializers.ModelSerializer):
    permissions = serializers.SerializerMethodField()
    class Meta:
        model = Section
        fields = ['id','slug','name','permissions']
        
    def get_permissions(self,obj):
        user = self.context['request'].user
        user_permissions = obj.get_user_permissions(user)
        return PermissionMinimizedSerializer(user_permissions,many=True).data
        
class AllSectionWisePermissionSerializer(serializers.ModelSerializer):
    permissions = PermissionMinimizedSerializer(many=True,source='get_all_permissions',read_only=True)
    class Meta:
        model = Section
        fields = '__all__'
class AssignPermissionToRoleSerializer(serializers.ModelSerializer):
    role = AccountRoleSerializer()
    permissions_details = PermissionMinimizedSerializer(many=True,source='permissions',read_only=True)
    
    class Meta:
        model = RolePermission
        fields = '__all__'
    
    def validate(self, data):
        # Validate role
        role_data = data.get('role', {})
        role_name = role_data.get('name')
        
        if not role_name:
            raise serializers.ValidationError({"role": {"name": "This field is required"}})
            
        # Check if we're updating an existing role (instance exists)
        if self.instance:
            # For update, check if name already exists (excluding current role)
            existing_role = Role.objects.filter(name=role_name).exclude(id=self.instance.role.id).first()
            if existing_role:
                raise serializers.ValidationError(f"Role with this name ({role_name}) already exists")
        else:
            # For create, check if name already exists
            existing_role = Role.objects.filter(name=role_name).first()
            if existing_role:
                raise serializers.ValidationError(f"Role with this name ({role_name}) already exists")
        
        # Validate permissions
        permissions = data.get('permissions', [])
        if not permissions:
            raise serializers.ValidationError({"permissions": "This field is required"})
            
        # # Check if all permission IDs exist
        # invalid_permissions = []
        # for permission_id in permissions:
        #     perm_obj = Permission.objects.filter(id=permission_id).first()
        #     if not perm_obj:
        #         invalid_permissions.append(permission_id)
                
        # if invalid_permissions:
        #     raise serializers.ValidationError({
        #         "permissions": f"The following permission IDs do not exist: {', '.join(map(str, invalid_permissions))}"
        #     })
            
        return data
    
    def create(self, validated_data):
        permissions = validated_data.pop('permissions')
        role_data = validated_data.pop('role')
        
        # Create the role
        role = Role.objects.create(**role_data)
        
        # Create the role permission relationship
        role_permission = RolePermission.objects.create(role=role)
        
        # Add permissions
        for perm_obj in permissions:
            role_permission.permissions.add(perm_obj)
            
        return role_permission
    
    def update(self, instance, validated_data):
        permissions = validated_data.pop('permissions')
        role_data = validated_data.pop('role')
        
        # Update the role
        instance.role.name = role_data.get('name', instance.role.name)
        if 'description' in role_data:
            instance.role.description = role_data.get('description')
        instance.role.save()
        
        # Update permissions
        instance.permissions.clear()
        for perm_obj in permissions:
            instance.permissions.add(perm_obj)
            
        return instance
    
class RolePermissionSerializer(serializers.Serializer):
    # account = AccountDetailsSerializer()
    permissions = serializers.ListField(child=serializers.CharField())

class HistorySerializer(serializers.Serializer):
    history_id = serializers.IntegerField()
    history_date = serializers.DateTimeField()
    history_type = serializers.CharField()
    history_user = serializers.SerializerMethodField()
    changed_fields = serializers.SerializerMethodField()

    def get_history_user(self, obj):
        if obj.history_user:
            return {
                'id': obj.history_user.id,
                'name': obj.history_user.name,
                'email': obj.history_user.email
            }
        return None

    def get_changed_fields(self, obj):
        if obj.prev_record:
            changed_fields = {}
            for field in [f.name for f in obj.instance._meta.fields]:
                old_value = getattr(obj.prev_record, field, None)
                new_value = getattr(obj, field, None)
                
                # Handle ForeignKey fields
                if isinstance(obj.instance._meta.get_field(field), models.ForeignKey):
                    # Handle Supplier objects which use uuid instead of id
                    if hasattr(old_value, 'uuid'):
                        old_value = old_value.uuid if old_value else None
                    else:
                        old_value = old_value.id if old_value else None
                    
                    if hasattr(new_value, 'uuid'):
                        new_value = new_value.uuid if new_value else None
                    else:
                        new_value = new_value.id if new_value else None
                        
                    if old_value != new_value:
                        changed_fields[field] = {
                            'old': old_value,
                            'new': new_value,
                            'type': 'foreign_key'
                        }
                # Handle regular fields
                elif old_value != new_value:
                    changed_fields[field] = {
                        'old': old_value,
                        'new': new_value,
                        'type': 'regular'
                    }
            
            # Handle ManyToMany fields
            for field in obj.instance._meta.many_to_many:
                try:
                    # Get current M2M values as a list of IDs
                    current_m2m = list(getattr(obj.instance, field.name).values_list('id', flat=True))
                    
                    # Get previous M2M values as a list of IDs
                    if hasattr(obj.prev_record, field.name):
                        old_m2m = list(getattr(obj.prev_record, field.name).values_list('id', flat=True))
                    else:
                        old_m2m = []
                    
                    if old_m2m != current_m2m:
                        changed_fields[field.name] = {
                            'old': old_m2m,
                            'new': current_m2m,
                            'type': 'many_to_many'
                        }
                except AttributeError:
                    continue
            
            return changed_fields
        return {}
