from django.core.management.base import BaseCommand
from msal import ConfidentialClientApplication
import requests

# Constants
CLIENT_ID = 'abce7dfa-4df4-4fae-93bb-554378661c80'
TENANT_ID = '8f221d92-5f71-4814-a944-9a960a6af444'
AUTHORITY = f'https://login.microsoftonline.com/{TENANT_ID}'
CLIENT_SECRET = 'vIf8Q~saE2aJeieHbcp1wpG-YMVCER1.jdfCHaym'  # Ensure this is correctly provided
# USER_ID='portal@paymentsave.co.uk'
USER_ID='no.reply@paymentsave.co.uk'


def get_access_token():
    # Initialize MSAL Confidential Client Application
    app = ConfidentialClientApplication(
        client_id=CLIENT_ID,
        authority=AUTHORITY,
        client_credential=CLIENT_SECRET
    )
    # Acquire Token
    result = app.acquire_token_for_client(scopes=['https://graph.microsoft.com/.default'])
    print(result)
    if 'access_token' not in result:
        raise Exception("Failed to acquire token: " + str(result.get('error_description')))

    token = result['access_token']
    return token

# Function to send email
def send_email(subject, body, recipient):
    access_token = get_access_token()
    url = f"https://graph.microsoft.com/v1.0/users/{USER_ID}/sendMail"
    headers = {
        'Authorization': 'Bearer ' + access_token,
        'Content-Type': 'application/json'
    }
    body = {
        "message": {
            "subject": subject,
            "body": {
                "contentType": "html",
                "content": body
            },
            "toRecipients": [
                {
                    "emailAddress": {
                        "address": recipient
                    }
                }
            ]
        },
        "saveToSentItems": "true"
    }
    response = requests.post(url, headers=headers, json=body)
    return response.status_code, response.text


