# Think---Feel----Develop
# created: 30-04-2024
# updated: 26-05-2024
# author: MD.Radwan Hossain(Arafath)
# All writtien content Copyright (C) 2024 MD.Radwan Hossain mdradwanhossain21@gmail.com
# This file is part of this project and can not be copied and/or distributed without the express
#  * permission of the author.

from rest_framework.renderers import JSONRenderer
import logging
logger = logging.getLogger('django')


class CustomRenderer(JSONRenderer):
    
    def render(self, data, accepted_media_type=None, renderer_context=None):
        status_code = renderer_context['response'].status_code
        if status_code == 204:
            response = {
                "status": "Success",
                "code": status_code,
                "message": "Request successfully executed",
                "data": None
            }
            return super(CustomRenderer, self).render(response, accepted_media_type, renderer_context)

        if not str(status_code).startswith('2'):
            logger.error(data)

        response = {
            "code": status_code,
            "message": None,
            "status": "success" if str(status_code).startswith('2') else "error",
            "data": None,
            "errors": None
        }

        if str(status_code).startswith('2'):
            if isinstance(data, dict):
                if 'data' in data:
                    response["data"] = data["data"]
                elif "detail" in data:
                    response["data"] = None
                else:
                    response["data"] = data
            else:
                response["data"] = data
        else:
            if isinstance(data, dict):
                if "detail" in data:
                    response["message"] = data["detail"]
                elif "message" in data:
                    response["message"] = data["message"]
                else:
                    response["message"] = "Validation error"
                    response["errors"] = data
            else:
                response["message"] = "Validation error"
                response["errors"] = data

        return super(CustomRenderer, self).render(response, accepted_media_type, renderer_context)

