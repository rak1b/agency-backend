from django.core.management.base import BaseCommand
import requests


class Command(BaseCommand):
    help = 'Initial application configuration'

    def handle(self, *args, **kwargs):
        from authentication.models import Section,Permission
        from utils.slug_utils import generate_unique_slug
        permissions = Permission.objects.all()
        for permission in permissions:
            permission.slug = generate_unique_slug(permission.name,permission)
            permission.save()
