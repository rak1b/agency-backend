from django.core.management.base import BaseCommand
from authentication.management.commands.data.permission_list import PERMISSION_LIST
from authentication.models import Section,Permission
def create_permissions():
    for section in PERMISSION_LIST:
        section_obj, created = Section.objects.get_or_create(name=section['section_name'])
        if created:
            print(f"Section {section['section_name']} created")
        section_permissions = section['permissions']
        for permission in section_permissions:
            permission_obj, created = Permission.objects.get_or_create(name=permission['name'],code=permission['code'],description=permission['description'], section=section_obj)
            if created:
                print(f"Permission {permission['name']} created")
            else:
                print(f"Permission {permission['name']} already exists")
                    


class Command(BaseCommand):
    help = 'Initial application configuration'

    def handle(self, *args, **kwargs):
        # create_groups()
        create_permissions()
        print("Initial setup completed")