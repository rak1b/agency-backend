from django.contrib import admin
from .models import User, Role, Permission, RolePermission, Merchant, Confirmation, OauthToken, Section 
from django.contrib.auth.hashers import make_password

admin.site.site_header = 'Paymentsave Inventory Management Portal'
admin.site.site_title = 'Paymentsave Inventory'

# Register your models here.
class CustomUserAdmin(admin.ModelAdmin):
    list_display = ('id','name','email','phone','is_active','is_superuser')
    search_fields = ('name','email','phone','role')
    list_filter = ('role',)
    filter_horizontal = ('groups',)
    exclude = ('user_permissions',)
    
    def save_model(self, request, obj, form, change):
        if form.cleaned_data['password'] and not form.cleaned_data['password'].startswith("pbkdf2"):
            obj.password = make_password(form.cleaned_data['password'])
        super().save_model(request, obj, form, change)

admin.site.register(User, CustomUserAdmin)
admin.site.register(Role)
admin.site.register(Permission)
admin.site.register(RolePermission)
admin.site.register(OauthToken)
admin.site.register(Merchant)
admin.site.register(Confirmation)
admin.site.register(Section)
